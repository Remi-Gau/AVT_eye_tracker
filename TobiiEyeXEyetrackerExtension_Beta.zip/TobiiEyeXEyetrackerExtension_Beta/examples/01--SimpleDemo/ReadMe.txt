/****************************************************************************
**
** ReadMe.txt
**
** Information about the SimpleDemo experiment
**
** Copyright (C) 2009 - 2011 FH JOANNEUM Gesellschaft mbH. All rights reserved.
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
****************************************************************************/

The demo shows how you can get gaze points from a Tobii eye tracker
in real time or buffered by Presentation. Also includes a simple calibration method.

The demo runs until the right mouse button or the X key is pressed.

Modify as needed.
