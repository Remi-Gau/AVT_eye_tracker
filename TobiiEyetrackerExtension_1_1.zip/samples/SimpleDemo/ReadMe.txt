/****************************************************************************
**
** ReadMe.txt
**
** Information about the tobiiSimpleDemo experiment
**
** Copyright (C) 2007 FH JOANNEUM Gesellschaft mbH. All rights reserved.
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
****************************************************************************/

The demo shows how you can capture gaze points from a Tobii eye tracker
in real time.

The demo runs until the right mouse button is pressed.

Modify as needed.
